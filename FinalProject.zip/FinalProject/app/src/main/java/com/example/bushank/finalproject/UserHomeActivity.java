package com.example.bushank.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterViewFlipper;
import android.widget.Button;

/**
 * Created by Sachin on 2/12/2020.
 */
public class UserHomeActivity extends AppCompatActivity {

    Button cvProduct, cvEquipment, cvFormer, cvFeedback,cvProfile,cvOrder,cvabout,cvCall;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userhome);

        cvProduct = (Button) findViewById(R.id.u2);
        cvEquipment = (Button) findViewById(R.id.u3);
        cvFormer = (Button) findViewById(R.id.u4);
        cvFeedback = (Button) findViewById(R.id.u5);


        cvProfile = (Button) findViewById(R.id.u1);
        cvOrder = (Button) findViewById(R.id.u6);
        cvabout = (Button) findViewById(R.id.u7);
        cvCall = (Button) findViewById(R.id.u8);

//

        cvProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplication(), UserProductActivity.class);
                startActivity(i);
            }
        });

        cvEquipment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplication(), UserEquipmentActivity.class);
                startActivity(i);
            }
        });

        cvFormer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplication(), UserFormerActivity.class);
                startActivity(i);
            }
        });

        cvFeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplication(), UserFeedbackActivity.class);
                startActivity(i);
            }
        });


        cvProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent clg = new Intent(getApplicationContext(),UserProfileActivity.class);
                startActivity(clg);
            }
        });

        cvOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent lib = new Intent(getApplicationContext(),UserOrdersActivity.class);
                startActivity(lib);
            }
        });

        cvabout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent feed = new Intent(getApplicationContext(),UserAboutAppActivity.class);
                startActivity(feed);

            }
        });


        cvCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call = new Intent(getApplicationContext(),UserCallUsActivity.class);
                startActivity(call);
            }
        });







    }




}
