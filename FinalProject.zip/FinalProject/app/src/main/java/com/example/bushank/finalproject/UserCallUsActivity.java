package com.example.bushank.finalproject;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

/**
 * Created by Sachin on 2/12/2020.
 */
public class UserCallUsActivity extends AppCompatActivity {
    Button button;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usercallus);

        button=(Button)findViewById(R.id.btn_call_kisan);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {

                Intent intent=new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse("tel:9448874424"));//change the number
                startActivity(intent);

            }
        });
    }
}
