package com.example.bushank.finalproject;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by Sachin on 2/12/2020.
 */
public class FormerRegisterActivity extends AppCompatActivity {

    TextInputLayout etName, etMobile, etAddress, etPassword;
    Button btnRegister;
    Spinner spinnerCity;
    String strName, strCity,  strMobile, strAddress, strPassword;
SharedPrefHandler sharedPrefHandler;


    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    String pattern = "[6-9][0-9]{10}";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formerregister);
sharedPrefHandler=new SharedPrefHandler(this);
        etName = (TextInputLayout) findViewById(R.id.et_formerregister_name);
        etMobile = (TextInputLayout) findViewById(R.id.et_formerregister_mobile);
        etAddress = (TextInputLayout) findViewById(R.id.et_formerregister_address);
        etPassword = (TextInputLayout) findViewById(R.id.et_formerregister_password);
        btnRegister = (Button) findViewById(R.id.btn_formerregister_register);
        spinnerCity = (Spinner) findViewById(R.id.spinner_formerregister_city);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                strName = etName.getEditText().getText().toString();
                strMobile = etMobile.getEditText().getText().toString();
                strAddress = etAddress.getEditText().getText().toString();
                strPassword = etPassword.getEditText().getText().toString();
                strCity = spinnerCity.getSelectedItem().toString();


                if (strName.isEmpty() ||   strMobile.length()<10 || strMobile.matches(pattern))
                {

                    Toast.makeText(FormerRegisterActivity.this, "Enter Valid Information", Toast.LENGTH_SHORT).show();
                }
            else
                {
                    sharedPrefHandler.setSharedPreferences("fmno",strMobile);
                    sharedPrefHandler.setSharedPreferences("fpass",strPassword);

                    CreateUserAccount();
                    Toast.makeText(FormerRegisterActivity.this, "Account Created successfully", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(getApplication(),FormerLoginActivity.class);
                    startActivity(intent);
                }



            }
        });
    }



    private void CreateUserAccount() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        Api api = retrofit.create(Api.class);

        Call<IsExist> call = api.CreateAccount(
                strName, strCity,  strMobile, strAddress, strPassword
        );

        call.enqueue(new Callback<IsExist>()
        {
            @Override
            public void onResponse(Call<IsExist> call, Response<IsExist> response) {
                IsExist responseResult = response.body();

                Boolean isSuccess = false;
                if(responseResult != null) {
                    isSuccess = responseResult.getSuccess();
                }

                if(isSuccess) {
                    Intent intent=new Intent(getApplication(),FormerLoginActivity.class);
                    startActivity(intent);

                    showCreateSuccessToast();

                } else {
                    // Show Creation Failed Message
                    showCreateFailedToast();
                }
            }

            @Override
            public void onFailure(Call<IsExist> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void showCreateFailedToast() {
        Toast.makeText(this, "OOPS,   Create action failed!", Toast.LENGTH_LONG).show();
    }

    private void showCreateSuccessToast() {
        Toast.makeText(this, "  created successfully.", Toast.LENGTH_LONG).show();
    }

    private void showEditFailedToast() {
        Toast.makeText(this, "OOPS,   Edit action failed!", Toast.LENGTH_LONG).show();
    }

    private void showEditSuccessToast() {
        Toast.makeText(this, "  updated successfully.", Toast.LENGTH_LONG).show();
    }



//    private class MyAsyncTask extends AsyncTask<String, Void, String>
//    {
//        private ProgressDialog progressDialog = new ProgressDialog(FormerRegisterActivity.this);
//
//        protected void onPreExecute()
//        {
//            progressDialog.setMessage("Please Wait");
//            progressDialog.show();
//
//        }
//        public void postData(String strName, String strCity, String strMobile, String strAddress,
//                             String strPassword)
//        {
//            // Create a new HttpClient and Post Header
//            HttpClient httpclient = new DefaultHttpClient();
//            HttpPost httppost = new HttpPost("https://phraseological-acco.000webhostapp.com/api/krushi_former_register.php");
//
//            try {
//                ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
//                //nameValuePairs.add(new BasicNameValuePair("f1", usn));
//                nameValuePairs.add(new BasicNameValuePair("f1", strName));
//                nameValuePairs.add(new BasicNameValuePair("f2", strCity));
//                nameValuePairs.add(new BasicNameValuePair("f3", strMobile));
//                nameValuePairs.add(new BasicNameValuePair("f4", strAddress));
//                nameValuePairs.add(new BasicNameValuePair("f5", strPassword));
//                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
//                Log.d("nameValuePairs", "" + nameValuePairs);
//                HttpResponse response = httpclient.execute(httppost);
//
//                HttpEntity entity = response.getEntity();
//
//
//                // If the response does not enclose an entity, there is no need
//                if (entity != null) {
//                    InputStream instream = entity.getContent();
//
//                    String result;
//                    result = convertStreamToString(instream);
//                    Log.d("respo", "" + result);
//                    JSONObject jsonObject = new JSONObject(result);
//                    String status = jsonObject.getString("success");
//                    Log.d("status", "" + status);
//
//
//                    if (status.equals("1"))
//
//                    {
//                        Intent intent=new Intent(getApplication(),FormerLoginActivity.class);
//                        startActivity(intent);
//                    }
//                    else
//                    {
//
//                    }
//
//
//                }
//
//
//            } catch (Exception e)
//            {
//                e.printStackTrace();
//            }
//        }
//
//        @Override
//        protected String doInBackground (String...params)
//        {
//            postData(strName, strCity, strMobile, strAddress, strPassword);
//            progressDialog.dismiss();
//            return null;
//        }
//        private  String convertStreamToString(InputStream is)
//        {
//            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
//            StringBuilder sb = new StringBuilder();
//
//            String line = null;
//            try {
//                while ((line = reader.readLine()) != null)
//                {
//                    sb.append(line + "\n");
//                }
//            }
//            catch (IOException e)
//            {
//                e.printStackTrace();
//            }
//            finally
//            {
//                try
//                {
//                    is.close();
//                } catch (IOException e)
//                {
//                    e.printStackTrace();
//                }
//            }
//            return sb.toString();
//        }
//    }
//    private void showToast(final String res)
//    {
//        runOnUiThread(new Runnable()
//        {
//            @Override
//            public void run()
//            {
//                //stuff that updates ui
//                if (res.equals("1"))
//                {
//                    Toast.makeText(getApplicationContext(), "  Account Create  Successful ", Toast.LENGTH_SHORT).show();
//
//                }
//                else
//                {
//                    Toast.makeText(getApplicationContext(), "Account Create Failed ", Toast.LENGTH_SHORT).show();
//                }
//            }
//        });
//    }
}
