package com.example.bushank.finalproject;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface Api {
    // String BASE_URL = "https://simplifiedcoding.net/demos/";

     String BASE_URL = "https://scolopendrine-locat.000webhostapp.com/krushi/api/";
    //String BASE_URL = "http://projectdevelopement.com/krushi/api/";

    String BASE_URL1 = "https://scolopendrine-locat.000webhostapp.com/krushi/api/formerlogin/";


    @GET("krushi_user_login.php")
        //i.e https://fanciful-petroleum.000webhostapp.com/api/user/login?mobileNo=9035292096&password=123456
    Call<IsExist> doLogin(@Query("mobileNo") String username, @Query("password") String password);



    @GET("krushi_former_login.php")
        //i.e https://fanciful-petroleum.000webhostapp.com/api/user/login?mobileNo=9035292096&password=123456
    Call<IsExist> doLogin1(@Query("mobileNo") String username, @Query("password") String password);


    @GET("krushi_fetch_former_profile.php")
    Call<List<Former>> getProductByCode(@Query("f1") String strMobile);


    @GET("krushi_fetch_city2.php")
    Call<List<Equipment>> getCityName();


    @GET("krushi-fetch_categories1.php")
    Call<List<Equipment>> getEquipmentName(@Query("f1") String strCity);


    @GET("krushi_fetch_product_details.php")
    Call<List<Product>> getProductId(@Query("f1") String strMobile, @Query("f2") String strPid);


    @GET("krushi_fetch_equipment_name.php")
    Call<List<Equipment>> getEquipmentName1(@Query("f1") String strCategory, @Query("f2") String strCity);



    @GET("krushi_fetch_equipment_details.php")
    Call<List<Equipment>> getEquipmentDetails(@Query("f1") String strCity, @Query("f2") String strCategory, @Query("f3") String strEquipmentName);


    @GET("krushi_fetch_categories3.php")
    Call<List<Order>> getOrderProductName1(@Query("f1") String strProduct, @Query("f2") String strCategory, @Query("f3") String strMobile);



    @GET("krushi_fetch_categories1.php")
    Call<List<Order>> getOrder(@Query("f1") String strMobile);


    @GET("krushi_fetch_user_details1.php")
    Call<List<Order>> getOrderDetails(@Query("f1") String strName);


    @GET("krushi_fetch_categories2.php")
    Call<List<Order>> getOrderProductName(@Query("f1") String strMobile, @Query("f2") String strCat);




    @POST("krushi_former_register.php")
    Call<IsExist> CreateAccount(
            @Query("f1") String strName,
            @Query("f2") String strCity,
            @Query("f3") String strMobile,
            @Query("f4") String strAddress,
            @Query("f5") String strPassword


    );


    @POST("krushi_delete_product.php")
    Call<IsExist> UpdateAccountProduct(
            @Query("f1") String strProductId


    );

    @POST("krushi_former_add_products.php")
    Call<IsExist> AddProduct(
            @Query("f1") String strPid,
            @Query("f2") String strPname,
            @Query("f3") String strCategory,
            @Query("f4") String strCity,
            @Query("f5") String strPrice,
            @Query("f6") String strMobile,
            @Query("f7") String strQuantity,
            @Query("f8") String strDescription


    );





    @POST("krushi_update_former_profile.php")
    Call<IsExist> UpdateAccount(
            @Query("f1") String strMobile,
            @Query("f2") String strFormerName,
            @Query("f3") String strCity,
            @Query("f4") String strAddress,
            @Query("f5") String strPassword


    );
    @POST("krushi_update_user_profile.php")
    Call<IsExist> UpdateUserAccount(
            @Query("f1") String strMobile,
            @Query("f2") String strName,
            @Query("f3") String strEmail,
            @Query("f4") String strCity,
            @Query("f5") String strAddress,
            @Query("f6") String strPassword


    );



    @POST("krushi_update_product.php")
    Call<IsExist> UpdateProduct(
            @Query("f1") String strMobile,
            @Query("f2") String strPid,
            @Query("f3") String strPname,
            @Query("f4") String strCategory,
            @Query("f5") String strCity,
            @Query("f6") String strPrice,
            @Query("f7") String strQuantity,
            @Query("f8") String strDescription


    );

    @POST("krushi_user_register.php")
    Call<IsExist> CreateAccountUser(
            @Query("f1") String strName,
            @Query("f2") String strMobile,
            @Query("f3") String strEmail,
            @Query("f4") String strCity,
            @Query("f5") String strAddress,
            @Query("f6") String strPassword


    );

    @GET("krushi_fetch_product_names.php")
    Call<List<Order>> getOrderName1(@Query("f1") String strMobile);


    @GET("krushi_fetch_user_orders.php")
    Call<List<Order>> getUserOrderDetails(@Query("f1") String strProductName);


    @GET("krushi_fetch_user_profile.php")
    Call<List<User>> getUserAccount(@Query("f1") String strMobile);


    @GET("krushi_fetch_city1.php")
    Call<List<Former>> getformer1();

    @GET("krushi_fetch_former_names.php")
    Call<List<Former>> getformername(@Query("f1") String strCity);

    @GET("krushi_fetch_former_details.php")
    Call<List<Former>> getFormerDetails(@Query("f1") String strFormerName);

    @GET("krushi_fetch_city2.php")
    Call<List<Equipment>> getEquipment();



    @GET("krushi-fetch_categories1.php")
    Call<List<Equipment>> getEquipment1(@Query("f1") String strCity);


    @GET("krushi_fetch_equipment_name.php")
    Call<List<Equipment>> getEquipment2(@Query("f1") String strCategory, @Query("f2") String strCity);


    @GET("krushi_fetch_equipment_details.php")
    Call<List<Equipment>> getEquipment3(@Query("f1") String strCity, @Query("f2") String strCategory, @Query("f3") String strEquipmentName);

    @GET("krushi_fetch_city.php")
    Call<List<Product>> getPrductCity();

    @GET("krushi_fetch_categories.php")
    Call<List<Product>> getProduct1(@Query("f1") String strCity);


    @GET("krushi_fetch_productnames.php")
    Call<List<Product>> getProduct2(@Query("f1") String strCity, @Query("f2") String strCategory);



    @GET("krushi_fetch_productdetails.php")
    Call<List<Product>> getProduct13(@Query("f1") String strCity, @Query("f2") String strCategory, @Query("f3") String strEquipmentName);


    @GET("fetch_notification.php")
    Call<List<Product>> getProductorder(@Query("f1") String strUserMobile);

    @GET("krushi_fetch_user_profile.php")
    Call<List<User>> getProductorder1(@Query("f1") String strUserMobile);


    @GET("fetch_product_list.php")
    Call<List<Product>> getProducts(@Query("f1") String string_fmno);



    @POST("krushi_place_order.php")
    Call<IsExist> Placeorder(
            @Query("f1") String strUserName,
            @Query("f2") String strUserMobile,
            @Query("f3") String strCity,
            @Query("f4") String strAddress,
            @Query("f5") String strProductId,
            @Query("f6") String strProductName,
            @Query("f7") String strCategory,
            @Query("f8") String strPrice,
            @Query("f9") String strQuantity,
            @Query("f10") String strFormerMobile);

}
