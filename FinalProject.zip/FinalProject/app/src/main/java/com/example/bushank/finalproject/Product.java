package com.example.bushank.finalproject;

public class Product {
    private String product_id;
    private String product_name;
    private String category;
    private String city;


    private String price;
    private String former_mobile;
    private String quantity;
    private String description;

    public Product(String product_id, String product_name, String category, String city,String price, String former_mobile, String quantity, String description) {

        this.product_id = product_id;
        this.product_name = product_name;
        this.category = category;
        this.city = city;




        this.price = price;
        this.former_mobile = former_mobile;
        this.quantity = quantity;
        this.description = description;


    }







    public String getproduct_id() {
        return product_id;
    }

    public void setproduct_id(String product_id) {
        this.product_id = product_id;
    }




    public String getproduct_name() {
        return product_name;
    }

    public void setproduct_name(String product_name) {
        this.product_name = product_name;
    }

    public String getcategory() {
        return category;
    }

    public void setcategory(String category) {
        this.category = category;
    }










    public String getcity() {
        return city;
    }

    public void setcity(String city) {
        this.city = city;
    }





    public String getprice() {
        return price;
    }

    public void setprice(String price) {
        this.price = price;
    }




    public String getformer_mobile() {
        return former_mobile;
    }

    public void setformer_mobile(String former_mobile) {
        this.former_mobile = former_mobile;
    }

    public String getquantity() {
        return quantity;
    }

    public void setquantity(String quantity) {
        this.quantity = quantity;
    }










    public String getdescription() {
        return description;
    }

    public void setdescription(String description) {
        this.description = description;
    }





}

