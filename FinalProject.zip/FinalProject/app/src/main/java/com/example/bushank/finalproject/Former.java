package com.example.bushank.finalproject;

public class Former {
    private String former_name;
    private String city;
    private String mobile_no;
    private String address;
    private String password;



    public Former(String former_name, String city, String mobile_no, String address, String password) {

        this.former_name = former_name;
        this.city = city;
        this.mobile_no = mobile_no;
        this.address = address;
        this.password = password;






    }







    public String getformer_name() {
        return former_name;
    }

    public void setformer_name(String former_name) {
        this.former_name = former_name;
    }




    public String getcity() {
        return city;
    }

    public void setcity(String city) {
        this.city = city;
    }

    public String getmobile_no() {
        return mobile_no;
    }

    public void setmobile_no(String mobile_no) {
        this.mobile_no = mobile_no;
    }










    public String getaddress() {
        return address;
    }

    public void setaddress(String address) {
        this.address = address;
    }





    public String getpassword() {
        return password;
    }

    public void setpassword(String password) {
        this.password = password;
    }




}

