package com.example.bushank.finalproject;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by Sachin on 2/13/2020.
 */
public class UserProduct3Activity extends AppCompatActivity{

    TextView tvProductId, tvProductName, tvCategory, tvCity, tvPrice, tvFormerMobile, tvDescription;
    EditText etQuantity;
    Button btnPlaceOrder;
    String strProductName, strProductId,strCategory, strCity, strPrice, strFormerMobile, strDescription, strQuantity;
    SharedPrefHandler sharedPrefHandler;
    List<Product> productList;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userproduct3);
        sharedPrefHandler = new SharedPrefHandler(this);
        strProductName = sharedPrefHandler.getSharedPreferences("product_name");
        strCity = sharedPrefHandler.getSharedPreferences("city");
        strCategory = sharedPrefHandler.getSharedPreferences("category");

        tvProductId = (TextView) findViewById(R.id.tv_userproduct3_productid);
        tvProductName = (TextView) findViewById(R.id.tv_userproduct3_productname);
        tvCategory = (TextView) findViewById(R.id.tv_userproduct3_category);
        tvCity = (TextView) findViewById(R.id.tv_userproduct3_city);
        tvPrice = (TextView) findViewById(R.id.tv_userproduct3_price);
        tvFormerMobile = (TextView) findViewById(R.id.tv_userproduct3_formermno);
        tvDescription = (TextView) findViewById(R.id.tv_userproduct3_desc);
        etQuantity = (EditText) findViewById(R.id.et_userproduct3_quantity);
        btnPlaceOrder = (Button) findViewById(R.id.btn_userproduct3_placeorder);

        btnPlaceOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                strCity = tvCity.getText().toString();
                strCategory = tvCategory.getText().toString();
                strPrice= tvPrice.getText().toString();
                strProductId = tvProductId.getText().toString();
                strFormerMobile = tvFormerMobile.getText().toString();
                strDescription = tvDescription.getText().toString();
                strQuantity = etQuantity.getText().toString();
                strProductName = tvProductName.getText().toString();

                sharedPrefHandler.setSharedPreferences("city", strCity);
                sharedPrefHandler.setSharedPreferences("category", strCategory);
                sharedPrefHandler.setSharedPreferences("price", strPrice);
                sharedPrefHandler.setSharedPreferences("productid", strProductId);
                sharedPrefHandler.setSharedPreferences("formermobile", strFormerMobile);
                sharedPrefHandler.setSharedPreferences("description", strDescription);
                sharedPrefHandler.setSharedPreferences("quantity", strQuantity);

                if (strQuantity.equals(""))
                {
                    Toast.makeText(UserProduct3Activity.this, "Enter Quantity", Toast.LENGTH_SHORT).show();
                }
                else {
                    Intent i = new Intent(getApplication(), UserProduct4Activity.class);
                    startActivity(i);
                }
            }
        });

        getProductByCode(strCity,strCategory,strProductName);

    }


    private void getProductByCode(final String strCity,final  String strCategory,final  String  strProductName) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();

        Api api = retrofit.create(Api.class);

        Call<List<Product>> call = api.getProduct13(strCity,strCategory,strProductName);

        call.enqueue(new Callback<List<Product>>() {
            @Override
            public void onResponse(Call<List<Product>> call, Response<List<Product>> response) {
                productList = response.body();

                Boolean isSuccess = false;
                if (response.body() != null) {
                    isSuccess = true;
                }

                if (isSuccess) {
                    tvProductId.setText(productList.get(0).getproduct_id());
                    tvProductName.setText(productList.get(0).getproduct_name());
                    tvCategory.setText(productList.get(0).getcategory());
                    tvCity.setText(productList.get(0).getcity());
                    tvPrice.setText(productList.get(0).getprice());
                    tvFormerMobile.setText(productList.get(0).getformer_mobile());
                    tvDescription.setText(productList.get(0).getdescription());






                } else {

                }
            }

            @Override
            public void onFailure(Call<List<Product>> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

//    private class MyAsyncTask extends AsyncTask<String, Void, String> {
//        private ProgressDialog progressDialog = new ProgressDialog(UserProduct3Activity.this);
//
//        protected void onPreExecute() {
//            progressDialog.setMessage("Fetching data...");
//            progressDialog.show();
//            progressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
//                @Override
//                public void onCancel(DialogInterface arg0) {
//                    MyAsyncTask.this.cancel(true);
//                }
//            });
//        }
//
//        public void postData(String strProductName, String strCity, String strCategory) {
//
//            // Create a new HttpClient and Post Header
//            HttpClient httpclient = new DefaultHttpClient();
//            HttpPost httppost = new HttpPost("https://phraseological-acco.000webhostapp.com/api/krushi_fetch_productdetails.php");
//
//            try {
//                ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
//                nameValuePairs.add(new BasicNameValuePair("f1", strProductName));
//                nameValuePairs.add(new BasicNameValuePair("f2", strCity));
//                nameValuePairs.add(new BasicNameValuePair("f3", strCategory));
//                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
//                Log.d("nameValuePairs", "" + nameValuePairs);
//                HttpResponse response = httpclient.execute(httppost);
//                HttpEntity entity = response.getEntity();
//
//
//                // If the response does not enclose an entity, there is no need
//                if (entity != null) {
//                    InputStream instream = entity.getContent();
//
//                    String result;
//                    result = convertStreamToString(instream);
//                    Log.d("aaa","" + result);
//
//
//                    JSONArray arr = new JSONArray(result);
//                    for (int i = 0; i < arr.length(); i++) {
//                        JSONObject jsonObject = arr.getJSONObject(i);
//                        String product_id = jsonObject.getString("product_id");
//                        String product_name = jsonObject.getString("product_name");
//                        String category = jsonObject.getString("category");
//                        String city = jsonObject.getString("city");
//                        String price = jsonObject.getString("price");
//                        String former_mobile = jsonObject.getString("former_mobile");
//                        String description = jsonObject.getString("description");
//
//
////                         //jsonObject.getString("name");
//
//
//                        //Toast.makeText(AttendanceDisplayActivity.this, ""+total1+absent1+present1, Toast.LENGTH_SHORT).show();
//
//                        setdata(product_id, product_name, category, city, price, former_mobile, description);
//                    }
//                }
//
//
//            } catch (Exception e) {
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        Toast.makeText(getApplicationContext(), "Something went wrong.Please try again.", Toast.LENGTH_LONG).show();
//                    }
//                });
//            }
//        }
//
//
//        public void setdata( final  String product_id, final  String product_name, final  String category, final  String city,
//                             final  String price, final  String former_mobile, final  String description)
//        {
//            runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//                    tvProductId.setText(product_id);
//                    tvProductName.setText(product_name);
//                    tvCategory.setText(category);
//                    tvCity.setText(city);
//                    tvPrice.setText(price);
//                    tvFormerMobile.setText(former_mobile);
//                    tvDescription.setText(description);
//
//
//                }
//            });
//
//        }
//        @Override
//        protected String doInBackground(String... params) {
//            postData(strProductName, strCity, strCategory);
//            //start loading proggress dialog
//            //pd= ProgressDialog.show(Chg_Password.this, "Loading...","");
//            this.progressDialog.dismiss();
//            return null;
//
//        }
//
//        /*
//        @Override
//
//        protected void onPostExecute(String s) {
//            super.onPostExecute(s);
//            //dissmiss
//            //pd.dismiss();
//            adp.notifyDataSetChanged();
//        }
//        */
//
//
//        private String convertStreamToString(InputStream is) {
//
//            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
//            StringBuilder sb = new StringBuilder();
//
//            String line = null;
//            try {
//                while ((line = reader.readLine()) != null) {
//                    sb.append(line + "\n");
//                }
//            } catch (Exception ex) {
//                Toast.makeText(getApplication(), ex.getMessage(), Toast.LENGTH_LONG).show();
//            }
//
//            result = sb.toString().trim();
//
//
//            result = result.substring(1, result.length() - 1);
//
//            if (!result.trim().equals("Error")) {
//                String[] r = result.split("-");
//
//
//            } else
//                Toast.makeText(getApplication(), "", Toast.LENGTH_LONG).show();
//            return sb.toString();
//        }
//
//        private void showToast(final String res) {
//            runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//                    //stuff that updates ui
//                    if (res.equals("1")) {
//                        Toast.makeText(getApplicationContext(), " Successfull", Toast.LENGTH_SHORT).show();
//
//                    } else {
//                        Toast.makeText(getApplicationContext(), " Failed ", Toast.LENGTH_SHORT).show();
//                    }
//                }
//            });
//        }
//    }
}
