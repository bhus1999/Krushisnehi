package com.example.bushank.finalproject;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by Sachin on 2/13/2020.
 */
public class UserProduct4Activity extends AppCompatActivity{

    EditText etName, etMobile, etCity, etAddress;
    Button btnConfirm;
    String strUserName, strUserMobile, strCity, strAddress, strProductId, strProductName, strCategory, strPrice, strQuantity, strFormerMobile;
    SharedPrefHandler sharedPrefHandler;
    List<User> productList;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userproduct4);
        sharedPrefHandler = new SharedPrefHandler(this);

        strUserMobile = sharedPrefHandler.getSharedPreferences("user_mobile");

        etName = (EditText) findViewById(R.id.et_userproduct4_username);
        etMobile = (EditText) findViewById(R.id.et_userproduct4_mobile);
        etCity = (EditText) findViewById(R.id.et_userproduct4_city);
        etAddress = (EditText) findViewById(R.id.et_userproduct4_address);
        btnConfirm = (Button) findViewById(R.id.btn_userproduct4_confirm);

        etMobile.setText(strUserMobile);
        getProductByCode(strUserMobile);

        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                strUserName = etName.getText().toString();
                strUserMobile = etMobile.getText().toString();
                strCity = etCity.getText().toString();
                strAddress = etAddress.getText().toString();

                strProductId = sharedPrefHandler.getSharedPreferences("productid");
                strProductName = sharedPrefHandler.getSharedPreferences("product_name");
                strCategory = sharedPrefHandler.getSharedPreferences("category");
                strPrice= sharedPrefHandler.getSharedPreferences("price");
                strQuantity = sharedPrefHandler.getSharedPreferences("quantity");
                strFormerMobile = sharedPrefHandler.getSharedPreferences("formermobile");

                if (strUserName.equals("") && strUserMobile.equals("") && strCity.equals("") && strAddress.equals(""))
                {
                    Toast.makeText(UserProduct4Activity.this, "Fill All Details", Toast.LENGTH_SHORT).show();
                }
                else {
                    UpdateProfile();
                    Intent intent=new Intent(getApplication(),UserHomeActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }



    private void getProductByCode(final String strUserMobile) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();

        Api api = retrofit.create(Api.class);

        Call<List<User>> call = api.getProductorder1(strUserMobile);

        call.enqueue(new Callback<List<User>>() {
            @Override
            public void onResponse(Call<List<User>> call, Response<List<User>> response) {
                productList = response.body();

                Boolean isSuccess = false;
                if (response.body() != null) {
                    isSuccess = true;
                }

                if (isSuccess) {
                    etName.setText(productList.get(0).getuser_name());
                    etCity.setText(productList.get(0).getcity());
                    etAddress.setText(productList.get(0).getaddress());




                } else {

                }
            }

            @Override
            public void onFailure(Call<List<User>> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void UpdateProfile() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        Api api = retrofit.create(Api.class);

        Call<IsExist> call = api.Placeorder(
                strUserName, strUserMobile, strCity, strAddress, strProductId, strProductName, strCategory, strPrice,
                strQuantity, strFormerMobile
        );

        call.enqueue(new Callback<IsExist>() {
            @Override
            public void onResponse(Call<IsExist> call, Response<IsExist> response) {
                IsExist responseResult = response.body();

                Boolean isSuccess = false;
                if (responseResult != null) {
                    isSuccess = responseResult.getSuccess();
                }

                if (isSuccess) {


                } else {
                    // Show Creation Failed Message

                }
            }

            @Override
            public void onFailure(Call<IsExist> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }



//
//
//    private class MyAsyncTask extends AsyncTask<String, Void, String>
//    {
//        private ProgressDialog progressDialog = new ProgressDialog(UserProduct4Activity.this);
//
//        protected void onPreExecute()
//        {
//            progressDialog.setMessage("Please Wait");
//            progressDialog.show();
//
//        }
//        public void postData(String strUserName, String strUserMobile, String strCity, String strAddress, String strProductId,
//                             String strProductName, String strCategory, String strPrice,
//                             String strQuantity, String strFormerMobile)
//        {
//            // Create a new HttpClient and Post Header
//            HttpClient httpclient = new DefaultHttpClient();
//            HttpPost httppost = new HttpPost("https://phraseological-acco.000webhostapp.com/api/krushi_place_order.php");
//
//            try {
//                ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
//                //nameValuePairs.add(new BasicNameValuePair("f1", usn));
//                nameValuePairs.add(new BasicNameValuePair("f1", strUserName));
//                nameValuePairs.add(new BasicNameValuePair("f2", strUserMobile));
//                nameValuePairs.add(new BasicNameValuePair("f3", strCity));
//                nameValuePairs.add(new BasicNameValuePair("f4", strAddress));
//                nameValuePairs.add(new BasicNameValuePair("f5", strProductId));
//                nameValuePairs.add(new BasicNameValuePair("f6", strProductName));
//                nameValuePairs.add(new BasicNameValuePair("f7", strCategory));
//                nameValuePairs.add(new BasicNameValuePair("f8", strPrice));
//                nameValuePairs.add(new BasicNameValuePair("f9", strQuantity));
//                nameValuePairs.add(new BasicNameValuePair("f10", strFormerMobile));
//
//
//
//                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
//                Log.d("nameValuePairs", "" + nameValuePairs);
//                HttpResponse response = httpclient.execute(httppost);
//
//                HttpEntity entity = response.getEntity();
//
//
//                // If the response does not enclose an entity, there is no need
//                if (entity != null) {
//                    InputStream instream = entity.getContent();
//
//                    String result;
//                    result = convertStreamToString(instream);
//                    Log.d("respo", "" + result);
//                    JSONObject jsonObject = new JSONObject(result);
//                    String status = jsonObject.getString("success");
//                    Log.d("status", "" + status);
//
//
//                    if (status.equals("1"))
//
//                    {
//                        Toast.makeText(UserProduct4Activity.this, " Order Placed Successfully", Toast.LENGTH_LONG).show();
//                        Intent intent=new Intent(getApplication(),UserHomeActivity.class);
//                        startActivity(intent);
//                    }
//                    else
//                    {
//
//                    }
//
//
//                }
//
//
//            } catch (Exception e)
//            {
//                e.printStackTrace();
//            }
//        }
//
//        @Override
//        protected String doInBackground (String...params)
//        {
//            postData(strUserName,strUserMobile,strCity,strAddress,strProductId,strProductName,strCategory,strPrice,strQuantity,strFormerMobile);
//            progressDialog.dismiss();
//            return null;
//        }
//        private  String convertStreamToString(InputStream is)
//        {
//            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
//            StringBuilder sb = new StringBuilder();
//
//            String line = null;
//            try {
//                while ((line = reader.readLine()) != null)
//                {
//                    sb.append(line + "\n");
//                }
//            }
//            catch (IOException e)
//            {
//                e.printStackTrace();
//            }
//            finally
//            {
//                try
//                {
//                    is.close();
//                } catch (IOException e)
//                {
//                    e.printStackTrace();
//                }
//            }
//            return sb.toString();
//        }
//    }
//    private void showToast(final String res)
//    {
//        runOnUiThread(new Runnable()
//        {
//            @Override
//            public void run()
//            {
//                //stuff that updates ui
//                if (res.equals("1"))
//                {
//                    Toast.makeText(getApplicationContext(), "  Account Create  Successful ", Toast.LENGTH_SHORT).show();
//
//                }
//                else
//                {
//                    Toast.makeText(getApplicationContext(), "Account Create Failed ", Toast.LENGTH_SHORT).show();
//                }
//            }
//        });
//    }
//
//
//
//
//    private class MyAsyncTask1 extends AsyncTask<String, Void, String> {
//        private ProgressDialog progressDialog = new ProgressDialog(UserProduct4Activity.this);
//
//        protected void onPreExecute() {
//            progressDialog.setMessage("Fetching data...");
//            progressDialog.show();
//            progressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
//                @Override
//                public void onCancel(DialogInterface arg0) {
//                    MyAsyncTask1.this.cancel(true);
//                }
//            });
//        }
//
//        public void postData(String strUserMobile) {
//
//
//            // Create a new HttpClient and Post Header
//            HttpClient httpclient = new DefaultHttpClient();
//            HttpPost httppost = new HttpPost("https://phraseological-acco.000webhostapp.com/api/krushi_fetch_user_details.php");
//
//            try {
//                ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
//                nameValuePairs.add(new BasicNameValuePair("f1", strUserMobile));
//
//                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
//                Log.d("nameValuePairs", "" + nameValuePairs);
//                HttpResponse response = httpclient.execute(httppost);
//                HttpEntity entity = response.getEntity();
//
//
//                // If the response does not enclose an entity, there is no need
//                if (entity != null) {
//                    InputStream instream = entity.getContent();
//
//                    String result;
//                    result = convertStreamToString(instream);
//                    Log.d("aaa","" + result);
//
//
//                    JSONArray arr = new JSONArray(result);
//                    for (int i = 0; i < arr.length(); i++) {
//                        JSONObject jsonObject = arr.getJSONObject(i);
//                        String user_name = jsonObject.getString("user_name");
//                        String city = jsonObject.getString("city");
//                        String address = jsonObject.getString("address");
//
//                        //jsonObject.getString("name");
//
//                        setdata(user_name, city, address);
//                    }
//                }
//
//            } catch (Exception e) {
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        Toast.makeText(getApplicationContext(), "Something went wrong.Please try again.", Toast.LENGTH_LONG).show();
//                    }
//                });
//            }
//        }
//
//        public void setdata( final  String user_name, final  String  city, final  String  address)
//        {
//            runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//                    etName.setText(user_name);
//                    etCity.setText(city);
//                    etAddress.setText(address);
//                }
//            });
//        }
//
//        @Override
//        protected String doInBackground(String... params) {
//            postData(strUserMobile);
//            //start loading proggress dialog
//            //pd= ProgressDialog.show(Chg_Password.this, "Loading...","");
//            this.progressDialog.dismiss();
//            return null;
//
//        }
//
//        /*
//        @Override
//
//        protected void onPostExecute(String s) {
//            super.onPostExecute(s);
//            //dissmiss
//            //pd.dismiss();
//            adp.notifyDataSetChanged();
//        }
//        */
//
//        private String convertStreamToString(InputStream is) {
//
//            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
//            StringBuilder sb = new StringBuilder();
//
//            String line = null;
//            try {
//                while ((line = reader.readLine()) != null) {
//                    sb.append(line + "\n");
//                }
//            } catch (Exception ex) {
//                Toast.makeText(getApplication(), ex.getMessage(), Toast.LENGTH_LONG).show();
//            }
//
//            result = sb.toString().trim();
//
//
//            result = result.substring(1, result.length() - 1);
//
//            if (!result.trim().equals("Error")) {
//                String[] r = result.split("-");
//
//            } else
//                Toast.makeText(getApplication(), "", Toast.LENGTH_LONG).show();
//            return sb.toString();
//        }
//
//        private void showToast(final String res) {
//            runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//                    //stuff that updates ui
//                    if (res.equals("1")) {
//                        Toast.makeText(getApplicationContext(), " Successfull", Toast.LENGTH_SHORT).show();
//
//                    } else {
//                        Toast.makeText(getApplicationContext(), " Failed ", Toast.LENGTH_SHORT).show();
//                    }
//                }
//            });
//        }
//
//    }
//

}
