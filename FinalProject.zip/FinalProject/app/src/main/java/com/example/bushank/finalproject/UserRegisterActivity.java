package com.example.bushank.finalproject;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by Sachin on 2/12/2020.
 */
public class UserRegisterActivity extends AppCompatActivity {

    TextInputLayout etName, etMobile, etEmail, etAddress, etPassword;
    Button btnRegister;
    Spinner spinnerCity;
    String strName, strMobile, strEmail, strAddress, strPassword, strCity;
SharedPrefHandler sharedPrefHandler;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    String pattern = "[6-9][0-9]{10}";
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userregister);

        sharedPrefHandler=new SharedPrefHandler(this);

        etName = (TextInputLayout) findViewById(R.id.et_userregister_name);
        etMobile = (TextInputLayout) findViewById(R.id.et_userregister_mobile);
        etEmail = (TextInputLayout) findViewById(R.id.et_userregister_email);
        etAddress = (TextInputLayout) findViewById(R.id.et_userregister_address);
        etPassword = (TextInputLayout) findViewById(R.id.et_userregister_password);
        btnRegister = (Button) findViewById(R.id.btn_userregister_register);
        spinnerCity = (Spinner) findViewById(R.id.spinner_userregister_city);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                strName = etName.getEditText().getText().toString();
                strMobile = etMobile.getEditText().getText().toString();
                strEmail = etEmail.getEditText().getText().toString();
                strAddress = etAddress.getEditText().getText().toString();
                strPassword = etPassword.getEditText().getText().toString();
                strCity = spinnerCity.getSelectedItem().toString();
                if (strName.isEmpty() || !strEmail.matches(emailPattern) ||  strMobile.length()<10 || strMobile.matches(pattern)) {

                    Toast.makeText(UserRegisterActivity.this, "Enter Valid Information", Toast.LENGTH_SHORT).show();
                }

                else {

                    sharedPrefHandler.setSharedPreferences("umno",strMobile);
                    sharedPrefHandler.setSharedPreferences("upass",strPassword);
                    CreateUserAccount();

                    Toast.makeText(UserRegisterActivity.this, "Account Created successfully", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(getApplication(),UserLoginActivity.class);
                            startActivity(intent);

                }
            }
        });
    }


    private void CreateUserAccount() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        Api api = retrofit.create(Api.class);

        Call<IsExist> call = api.CreateAccountUser(
                strName, strMobile, strEmail, strCity,strAddress, strPassword
        );

        call.enqueue(new Callback<IsExist>()
        {
            @Override
            public void onResponse(Call<IsExist> call, Response<IsExist> response) {
                IsExist responseResult = response.body();

                Boolean isSuccess = false;
                if(responseResult != null) {
                    isSuccess = responseResult.getSuccess();
                }

                if(isSuccess) {
                    Intent intent=new Intent(getApplication(),UserLoginActivity.class);
                    startActivity(intent);

                    showCreateSuccessToast();

                } else {
                    // Show Creation Failed Message
                    showCreateFailedToast();
                }
            }

            @Override
            public void onFailure(Call<IsExist> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void showCreateFailedToast() {
        Toast.makeText(this, "OOPS,   Create action failed!", Toast.LENGTH_LONG).show();
    }

    private void showCreateSuccessToast() {
        Toast.makeText(this, "  created successfully.", Toast.LENGTH_LONG).show();
    }

    private void showEditFailedToast() {
        Toast.makeText(this, "OOPS,   Edit action failed!", Toast.LENGTH_LONG).show();
    }

    private void showEditSuccessToast() {
        Toast.makeText(this, "  updated successfully.", Toast.LENGTH_LONG).show();
    }
}
