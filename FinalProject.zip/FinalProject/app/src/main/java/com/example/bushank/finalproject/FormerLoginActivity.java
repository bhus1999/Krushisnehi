package com.example.bushank.finalproject;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;



import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class FormerLoginActivity extends AppCompatActivity{

    EditText etMobile, etPassword;
    Button btnLogin;
    TextView tvRegister, tvForgotPassword;


    SharedPrefHandler sharedPrefHandler;

    ProgressDialog progressBar;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formerlogin);
        sharedPrefHandler = new SharedPrefHandler(this);

        etMobile = (EditText) findViewById(R.id.et_formerlogin_mobile);
        etPassword = (EditText) findViewById(R.id.et_formerlogin_password);
        tvRegister = (TextView) findViewById(R.id.tv_formerlogin_register);

        btnLogin = (Button) findViewById(R.id.btn_formerlogin_login);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = etMobile.getText().toString();
                String password = etPassword.getText().toString();

                sharedPrefHandler.setSharedPreferences("former_mobile",username);
                //validate form
                if(validateLogin(username, password)) {

                    String username1 = sharedPrefHandler.getSharedPreferences("fmno");
                    String password2 =  sharedPrefHandler.getSharedPreferences("fpass");

                    if (username.equals(username1) && password.equals(password2)) {

                        Intent intent = new Intent(getApplication(), FormerHomeActivity.class);
                        startActivity(intent);
                        finish();
                    }
                    else {
                        Toast.makeText(FormerLoginActivity.this, "Incorrect Username or Password", Toast.LENGTH_LONG).show();
                    }
                }

            }
        });

        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getBaseContext(),FormerRegisterActivity.class);
                startActivity(i);
            }
        });

//        tvForgotPassword.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent i=new Intent(getBaseContext(),FormerForgotPasswordActivity.class);
//                startActivity(i);
//            }
//        });
    }


    private boolean validateLogin(final String username, final String password){
        if(username == null || username.trim().length() == 0){
            Toast.makeText(this, "Username is required", Toast.LENGTH_LONG).show();
            return false;
        }
        if(password == null || password.trim().length() == 0){
            Toast.makeText(this, "Password is required", Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }

    private void doLogin(final String username, final String password){
        // creating progress bar dialog
        progressBar = new ProgressDialog(this);
        progressBar.setCancelable(false);
        progressBar.setMessage("Please wait...");
        progressBar.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        // progressBar.setProgress(0);
        // progressBar.setMax(100);
        progressBar.show();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_URL1)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();

        Api api = retrofit.create(Api.class);

        Call<IsExist> call = api.doLogin1(username, password);

        call.enqueue(new Callback<IsExist>() {
            @Override
            public void onResponse(Call<IsExist> call, Response<IsExist> response) {
                IsExist responseResult = response.body();

                Boolean isSuccess = false;
                if(responseResult != null) {
                    isSuccess = responseResult.getSuccess();
                }

                if(isSuccess) {
                    progressBar.dismiss();

                    Intent intent = new Intent(getApplication(),FormerHomeActivity.class);
                    startActivity(intent);
                    finish();


                } else {
                    // Show Login Failed Message
                    progressBar.dismiss();
                    showLoginFailedToast();
                }
            }

            @Override
            public void onFailure(Call<IsExist> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showLoginFailedToast() {
        Toast.makeText(this, "Incorrect Username or Password", Toast.LENGTH_LONG).show();
    }


}
