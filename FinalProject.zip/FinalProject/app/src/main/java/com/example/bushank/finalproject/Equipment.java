package com.example.bushank.finalproject;

public class Equipment {
    private String equipment_name;
    private String category;
    private String city;
    private String seller_name;


    private String mobile_no;
    private String price;
    private String description;


    public Equipment(String equipment_name, String category, String city, String ciseller_namety, String mobile_no, String price, String description) {

        this.equipment_name = equipment_name;
        this.category = category;
        this.city = city;
        this.seller_name = seller_name;




        this.mobile_no = mobile_no;
        this.price = price;
        this.description = description;



    }







    public String getequipment_name() {
        return equipment_name;
    }

    public void setequipment_name(String equipment_name) {
        this.equipment_name = equipment_name;
    }





    public String getcategory() {
        return category;
    }

    public void setcategory(String category) {
        this.category = category;
    }










    public String getcity() {
        return city;
    }

    public void setcity(String city) {
        this.city = city;
    }





    public String getprice() {
        return price;
    }

    public void setprice(String price) {
        this.price = price;
    }




    public String getseller_name	() {
        return seller_name	;
    }

    public void setseller_name	(String former_mobile) {
        this.seller_name	 = seller_name	;
    }

    public String getmobile_no() {
        return mobile_no;
    }

    public void setmobile_no(String mobile_no) {
        this.mobile_no = mobile_no;
    }










    public String getdescription() {
        return description;
    }

    public void setdescription(String description) {
        this.description = description;
    }





}

