package com.example.bushank.finalproject;

public class Order {
    private String user_name;
    private String mobile_no;
    private String city;
    private String address;


    private String product_id;
    private String product_name;
    private String category;
    private String price;

    private String quantity;
    private String former_mobile;

    public Order(String user_name, String mobile_no, String city, String address, String product_id, String product_name, String category, String price, String quantity, String former_mobile) {

        this.user_name = user_name;
        this.mobile_no = mobile_no;
        this.city = city;
        this.address = address;




        this.product_id = product_id;
        this.product_name = product_name;
        this.category = category;
        this.price = price;

        this.quantity = quantity;
        this.former_mobile = former_mobile;


    }







    public String getproduct_id() {
        return product_id;
    }

    public void setproduct_id(String product_id) {
        this.product_id = product_id;
    }




    public String getproduct_name() {
        return product_name;
    }

    public void setproduct_name(String product_name) {
        this.product_name = product_name;
    }

    public String getcategory() {
        return category;
    }

    public void setcategory(String category) {
        this.category = category;
    }










    public String getcity() {
        return city;
    }

    public void setcity(String city) {
        this.city = city;
    }





    public String getprice() {
        return price;
    }

    public void setprice(String price) {
        this.price = price;
    }




    public String getformer_mobile() {
        return former_mobile;
    }

    public void setformer_mobile(String former_mobile) {
        this.former_mobile = former_mobile;
    }

    public String getquantity() {
        return quantity;
    }

    public void setquantity(String quantity) {
        this.quantity = quantity;
    }










    public String getuser_name() {
        return user_name;
    }

    public void setuser_name(String user_name) {
        this.user_name = user_name;
    }



    public String getmobile_no() {
        return mobile_no;
    }

    public void setmobile_no(String mobile_no) {
        this.mobile_no = mobile_no;
    }


    public String getaddress() {
        return address;
    }

    public void setaddress(String address) {
        this.address = address;
    }


}

