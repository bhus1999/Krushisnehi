package com.example.bushank.finalproject;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by Sachin on 2/12/2020.
 */
public class FormerDeleteProductActivity extends AppCompatActivity {

    EditText etPid;
    Button btnDelete;
    String strProductId;
    SharedPrefHandler sharedPrefHandler;
    List<Product> productList;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formerdeleteproduct);
        sharedPrefHandler = new SharedPrefHandler(this);

        etPid = (EditText) findViewById(R.id.et_formerdeleteproduct_pid);
        btnDelete = (Button) findViewById(R.id.btn_formerdeleteproduct_delete);

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                strProductId = etPid.getText().toString();
                UpdateProfile();
            }
        });
    }


    private void UpdateProfile() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        Api api = retrofit.create(Api.class);

        Call<IsExist> call = api.UpdateAccountProduct(
                strProductId
        );

        call.enqueue(new Callback<IsExist>() {
            @Override
            public void onResponse(Call<IsExist> call, Response<IsExist> response) {
                IsExist responseResult = response.body();

                Boolean isSuccess = false;
                if (responseResult != null) {
                    isSuccess = responseResult.getSuccess();
                }

                if (isSuccess) {


                } else {
                    // Show Creation Failed Message

                }
            }

            @Override
            public void onFailure(Call<IsExist> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }





//    private class MyAsyncTask extends AsyncTask<String, Void, String>
//    {
//        private ProgressDialog progressDialog = new ProgressDialog(FormerDeleteProductActivity.this);
//
//        protected void onPreExecute()
//        {
//            progressDialog.setMessage("Please Wait");
//            progressDialog.show();
//
//        }
//        public void postData(String strProductId)
//        {
//            // Create a new HttpClient and Post Header
//            HttpClient httpclient = new DefaultHttpClient();
//            HttpPost httppost = new HttpPost("https://phraseological-acco.000webhostapp.com/api/krushi_delete_product.php");
//
//            try {
//                ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
//                //nameValuePairs.add(new BasicNameValuePair("f1", usn));
//                nameValuePairs.add(new BasicNameValuePair("f1", strProductId));
//
//                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
//                Log.d("nameValuePairs", "" + nameValuePairs);
//                HttpResponse response = httpclient.execute(httppost);
//
//                HttpEntity entity = response.getEntity();
//
//
//                // If the response does not enclose an entity, there is no need
//                if (entity != null) {
//                    InputStream instream = entity.getContent();
//
//                    String result;
//                    result = convertStreamToString(instream);
//                    Log.d("respo", "" + result);
//                    JSONObject jsonObject = new JSONObject(result);
//                    String status = jsonObject.getString("success");
//                    Log.d("status", "" + status);
//
//
//                    if (status.equals("1"))
//
//                    {   showToast(status);
//                        Intent intent=new Intent(getApplication(),FormerProductActivity.class);
//                        startActivity(intent);
//                    }
//                    else
//                    {
//
//                    }
//
//
//                }
//
//
//            } catch (Exception e)
//            {
//                e.printStackTrace();
//            }
//        }
//
//        @Override
//        protected String doInBackground (String...params)
//        {
//            postData(strProductId);
//            progressDialog.dismiss();
//            return null;
//        }
//        private  String convertStreamToString(InputStream is)
//        {
//            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
//            StringBuilder sb = new StringBuilder();
//
//            String line = null;
//            try {
//                while ((line = reader.readLine()) != null)
//                {
//                    sb.append(line + "\n");
//                }
//            }
//            catch (IOException e)
//            {
//                e.printStackTrace();
//            }
//            finally
//            {
//                try
//                {
//                    is.close();
//                } catch (IOException e)
//                {
//                    e.printStackTrace();
//                }
//            }
//            return sb.toString();
//        }
//    }
//    private void showToast(final String res)
//    {
//        runOnUiThread(new Runnable()
//        {
//            @Override
//            public void run()
//            {
//                //stuff that updates ui
//                if (res.equals("1"))
//                {
//                    Toast.makeText(getApplicationContext(), "  Deletion Successful ", Toast.LENGTH_LONG).show();
//
//                }
//                else
//                {
//                    Toast.makeText(getApplicationContext(), "Delition Failed ", Toast.LENGTH_LONG).show();
//                }
//            }
//        });
//    }

}
