package com.example.bushank.finalproject;

public class User {
    private String user_name;
    private String city;
    private String mobile_no;
    private String address;
    private String password;
    private String email;



    public User(String user_name, String city, String mobile_no, String address, String password, String email) {

        this.user_name = user_name;
        this.city = city;
        this.mobile_no = mobile_no;
        this.address = address;
        this.email = email;
        this.password = password;






    }







    public String getuser_name() {
        return user_name;
    }

    public void setuser_name(String user_name) {
        this.user_name = user_name;
    }




    public String getcity() {
        return city;
    }

    public void setcity(String city) {
        this.city = city;
    }

    public String getmobile_no() {
        return mobile_no;
    }

    public void setmobile_no(String mobile_no) {
        this.mobile_no = mobile_no;
    }










    public String getaddress() {
        return address;
    }

    public void setaddress(String address) {
        this.address = address;
    }





    public String getpassword() {
        return password;
    }

    public void setpassword(String password) {
        this.password = password;
    }





    public String getemail() {
        return email;
    }

    public void setemail(String email) {
        this.email = email;
    }



}

