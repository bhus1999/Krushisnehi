package com.example.bushank.finalproject;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by Sachin on 2/12/2020.
 */
public class FormerAddProductActivity extends AppCompatActivity{

    TextInputLayout etPid, etPname, etPrice, etQuantity, etDescription;
    Spinner spinnerCategory, spinnerCity;
    Button btnAdd;
    String strMobile, strPid, strPname, strPrice, strQuantity, strDescription, strCategory, strCity;
    SharedPrefHandler sharedPrefHandler;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formeraddproduct);
        sharedPrefHandler = new SharedPrefHandler(this);
        strMobile = sharedPrefHandler.getSharedPreferences("former_mobile");


        etPid = (TextInputLayout) findViewById(R.id.et_formeraddproduct_pid);
        etPname = (TextInputLayout) findViewById(R.id.et_formeraddproduct_pname);
        etPrice = (TextInputLayout) findViewById(R.id.et_formeraddproduct_price);
        etQuantity = (TextInputLayout) findViewById(R.id.et_formeraddproduct_quantity);
        etDescription = (TextInputLayout) findViewById(R.id.et_formeraddproduct_desc);
        spinnerCategory = (Spinner) findViewById(R.id.spinner_formeraddproduct_category);
        spinnerCity= (Spinner) findViewById(R.id.spinner_formeraddproduct_city);
        btnAdd = (Button) findViewById(R.id.btn_formeraddproduct_add);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                strPid = etPid.getEditText().getText().toString();
                strPname = etPname.getEditText().getText().toString();
                strCategory = spinnerCategory.getSelectedItem().toString();
                strCity = spinnerCity.getSelectedItem().toString();
                strPrice = etPrice.getEditText().getText().toString();
                strQuantity = etQuantity.getEditText().getText().toString();
                strDescription = etDescription.getEditText().getText().toString();
                if (strPid.equals("") && strPname.equals("") && strPrice.equals("")  && strQuantity.equals("") )
                {
                    Toast.makeText(FormerAddProductActivity.this, "Please Enter All Details", Toast.LENGTH_SHORT).show();
                }
                else {
                    CreateUserAccount();

                    Intent i = new Intent(getApplication(), FormerProductActivity.class);
                    startActivity(i);
                    finish();
                }
            }
        });
    }



    private void CreateUserAccount() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        Api api = retrofit.create(Api.class);

        Call<IsExist> call = api.AddProduct(

                strPid,strPname,strCategory,strCity,strPrice,strMobile,strQuantity,strDescription

        );

        call.enqueue(new Callback<IsExist>()
        {
            @Override
            public void onResponse(Call<IsExist> call, Response<IsExist> response) {
                IsExist responseResult = response.body();

                Boolean isSuccess = false;
                if(responseResult != null) {
                    isSuccess = responseResult.getSuccess();
                }

                if(isSuccess) {
                    Intent intent=new Intent(getApplication(),FormerHomeActivity.class);
                    startActivity(intent);

                    showCreateSuccessToast();

                } else {
                    // Show Creation Failed Message
                    showCreateFailedToast();
                }
            }

            @Override
            public void onFailure(Call<IsExist> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void showCreateFailedToast() {
        Toast.makeText(this, "OOPS,   Create action failed!", Toast.LENGTH_LONG).show();
    }

    private void showCreateSuccessToast() {
        Toast.makeText(this, "  created successfully.", Toast.LENGTH_LONG).show();
    }

    private void showEditFailedToast() {
        Toast.makeText(this, "OOPS,   Edit action failed!", Toast.LENGTH_LONG).show();
    }

    private void showEditSuccessToast() {
        Toast.makeText(this, "  updated successfully.", Toast.LENGTH_LONG).show();
    }


//    private class MyAsyncTask extends AsyncTask<String, Void, String>
//    {
//        private ProgressDialog progressDialog = new ProgressDialog(FormerAddProductActivity.this);
//
//        protected void onPreExecute()
//        {
//            progressDialog.setMessage("Please Wait");
//            progressDialog.show();
//
//        }
//        public void postData(String strPid, String strPname, String strCategory, String strCity, String strPrice,
//                             String strMobile, String strQuantity, String strDescription)
//        {
//            // Create a new HttpClient and Post Header
//            HttpClient httpclient = new DefaultHttpClient();
//            HttpPost httppost = new HttpPost("https://phraseological-acco.000webhostapp.com/api/krushi_former_add_products.php");
//
//            try {
//                ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
//                //nameValuePairs.add(new BasicNameValuePair("f1", usn));
//                nameValuePairs.add(new BasicNameValuePair("f1", strPid));
//                nameValuePairs.add(new BasicNameValuePair("f2", strPname));
//                nameValuePairs.add(new BasicNameValuePair("f3", strCategory));
//                nameValuePairs.add(new BasicNameValuePair("f4", strCity));
//                nameValuePairs.add(new BasicNameValuePair("f5", strPrice));
//                nameValuePairs.add(new BasicNameValuePair("f6", strMobile));
//                nameValuePairs.add(new BasicNameValuePair("f7", strQuantity));
//                nameValuePairs.add(new BasicNameValuePair("f8", strDescription));
//
//                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
//                Log.d("nameValuePairs", "" + nameValuePairs);
//                HttpResponse response = httpclient.execute(httppost);
//
//                HttpEntity entity = response.getEntity();
//
//
//                // If the response does not enclose an entity, there is no need
//                if (entity != null) {
//                    InputStream instream = entity.getContent();
//
//                    String result;
//                    result = convertStreamToString(instream);
//                    Log.d("respo", "" + result);
//                    JSONObject jsonObject = new JSONObject(result);
//                    String status = jsonObject.getString("success");
//                    Log.d("status", "" + status);
//
//
//                    if (status.equals("1"))
//
//                    {
//                        Intent intent=new Intent(getApplication(),FormerProductActivity.class);
//                        startActivity(intent);
//                    }
//                    else
//                    {
//
//                    }
//
//
//                }
//
//
//            } catch (Exception e)
//            {
//                e.printStackTrace();
//            }
//        }
//
//        @Override
//        protected String doInBackground (String...params)
//        {
//            postData(strPid, strPname, strCategory, strCity, strPrice, strMobile, strQuantity, strDescription);
//            progressDialog.dismiss();
//            return null;
//        }
//        private  String convertStreamToString(InputStream is)
//        {
//            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
//            StringBuilder sb = new StringBuilder();
//
//            String line = null;
//            try {
//                while ((line = reader.readLine()) != null)
//                {
//                    sb.append(line + "\n");
//                }
//            }
//            catch (IOException e)
//            {
//                e.printStackTrace();
//            }
//            finally
//            {
//                try
//                {
//                    is.close();
//                } catch (IOException e)
//                {
//                    e.printStackTrace();
//                }
//            }
//            return sb.toString();
//        }
//    }
//    private void showToast(final String res)
//    {
//        runOnUiThread(new Runnable()
//        {
//            @Override
//            public void run()
//            {
//                //stuff that updates ui
//                if (res.equals("1"))
//                {
//                    Toast.makeText(getApplicationContext(), "  Account Create  Successful ", Toast.LENGTH_SHORT).show();
//
//                }
//                else
//                {
//                    Toast.makeText(getApplicationContext(), "Account Create Failed ", Toast.LENGTH_SHORT).show();
//                }
//            }
//        });
//    }
}
