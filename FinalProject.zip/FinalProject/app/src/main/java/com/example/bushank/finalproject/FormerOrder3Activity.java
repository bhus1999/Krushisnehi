package com.example.bushank.finalproject;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by Sachin on 2/15/2020.
 */
public class FormerOrder3Activity extends AppCompatActivity{

    TextView tvUserName, tvMobile, tvCity, tvAddress, tvPid, tvPname, tvCat, tvPrice, tvQuantity;
    String strName;
    SharedPrefHandler sharedPrefHandler;
    List<Order> productList;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formerorder3);
        sharedPrefHandler = new SharedPrefHandler(this);
        strName = sharedPrefHandler.getSharedPreferences("name");

        tvUserName = (TextView) findViewById(R.id.tv_formerorder3_username);
        tvMobile = (TextView) findViewById(R.id.tv_formerorder3_mobile);
        tvCity = (TextView) findViewById(R.id.tv_formerorder3_city);
        tvAddress = (TextView) findViewById(R.id.tv_formerorder3_address);
        tvPid = (TextView) findViewById(R.id.tv_formerorder3_productid);
        tvPname = (TextView) findViewById(R.id.tv_formerorder3_Productname);
        tvCat = (TextView) findViewById(R.id.tv_formerorder3_category);
        tvPrice = (TextView) findViewById(R.id.tv_formerorder3_price);
        tvQuantity = (TextView) findViewById(R.id.tv_formerorder3_quantity);

        tvUserName.setText(strName);

        getProductByCode(strName);
    }

    private void getProductByCode(final String strName) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();

        Api api = retrofit.create(Api.class);

        Call<List<Order>> call = api.getOrderDetails(strName);

        call.enqueue(new Callback<List<Order>>() {
            @Override
            public void onResponse(Call<List<Order>> call, Response<List<Order>> response) {
                productList = response.body();

                Boolean isSuccess = false;
                if (response.body() != null) {
                    isSuccess = true;
                }

                if (isSuccess) {
                    tvMobile.setText(productList.get(0).getmobile_no());
                    tvCity.setText(productList.get(0).getcity());
                    tvAddress.setText(productList.get(0).getaddress());
                    tvPid.setText(productList.get(0).getproduct_id());
                    tvPname.setText(productList.get(0).getproduct_name());
                    tvCat.setText(productList.get(0).getcategory());
                    tvPrice.setText(productList.get(0).getprice());
                    tvQuantity.setText(productList.get(0).getquantity());


                    //finish();

                } else {

                }
            }

            @Override
            public void onFailure(Call<List<Order>> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }


//
//    private class MyAsyncTask extends AsyncTask<String, Void, String> {
//        private ProgressDialog progressDialog = new ProgressDialog(FormerOrder3Activity.this);
//
//        protected void onPreExecute() {
//            progressDialog.setMessage("Fetching data...");
//            progressDialog.show();
//            progressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
//                @Override
//                public void onCancel(DialogInterface arg0) {
//                    MyAsyncTask.this.cancel(true);
//                }
//            });
//        }
//
//        public void postData(String strName) {
//
//            // Create a new HttpClient and Post Header
//            HttpClient httpclient = new DefaultHttpClient();
//            HttpPost httppost = new HttpPost("https://phraseological-acco.000webhostapp.com/api/krushi_fetch_user_details1.php");
//
//            try {
//                ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
//                nameValuePairs.add(new BasicNameValuePair("f1", strName));
//                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
//                Log.d("nameValuePairs", "" + nameValuePairs);
//                HttpResponse response = httpclient.execute(httppost);
//                HttpEntity entity = response.getEntity();
//
//
//                // If the response does not enclose an entity, there is no need
//                if (entity != null) {
//                    InputStream instream = entity.getContent();
//
//                    String result;
//                    result = convertStreamToString(instream);
//                    Log.d("aaa","" + result);
//
//
//                    JSONArray arr = new JSONArray(result);
//                    for (int i = 0; i < arr.length(); i++) {
//                        JSONObject jsonObject = arr.getJSONObject(i);
//                        String mobile_no = jsonObject.getString("mobile_no");
//                        String city = jsonObject.getString("city");
//                        String address = jsonObject.getString("address");
//                        String product_id = jsonObject.getString("product_id");
//                        String product_name = jsonObject.getString("product_name");
//                        String category  = jsonObject.getString("category");
//                        String price  = jsonObject.getString("price");
//                        String quantity = jsonObject.getString("quantity");
//
////                         //jsonObject.getString("name");
//
//
//                        //Toast.makeText(AttendanceDisplayActivity.this, ""+total1+absent1+present1, Toast.LENGTH_SHORT).show();
//
//                        setdata(mobile_no, city, address, product_id, product_name, category, price, quantity);
//                    }
//                }
//
//
//            } catch (Exception e) {
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        Toast.makeText(getApplicationContext(), "Something went wrong.Please try again.", Toast.LENGTH_LONG).show();
//                    }
//                });
//            }
//        }
//
//
//        public void setdata( final  String mobile_no, final  String city, final  String address,
//                             final  String product_id, final  String product_name,
//                             final  String category, final  String price, final  String quantity)
//        {
//            runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//                    tvMobile.setText(mobile_no);
//                    tvCity.setText(city);
//                    tvAddress.setText(address);
//                    tvPid.setText(product_id);
//                    tvPname.setText(product_name);
//                    tvCat.setText(category);
//                    tvPrice.setText(price);
//                    tvQuantity.setText(quantity);
//                }
//            });
//
//        }
//        @Override
//        protected String doInBackground(String... params) {
//            postData(strName);
//            //start loading proggress dialog
//            //pd= ProgressDialog.show(Chg_Password.this, "Loading...","");
//            this.progressDialog.dismiss();
//            return null;
//
//        }
//
//        /*
//        @Override
//
//        protected void onPostExecute(String s) {
//            super.onPostExecute(s);
//            //dissmiss
//            //pd.dismiss();
//            adp.notifyDataSetChanged();
//        }
//        */
//
//
//        private String convertStreamToString(InputStream is) {
//
//            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
//            StringBuilder sb = new StringBuilder();
//
//            String line = null;
//            try {
//                while ((line = reader.readLine()) != null) {
//                    sb.append(line + "\n");
//                }
//            } catch (Exception ex) {
//                Toast.makeText(getApplication(), ex.getMessage(), Toast.LENGTH_LONG).show();
//            }
//
//            result = sb.toString().trim();
//
//
//            result = result.substring(1, result.length() - 1);
//
//            if (!result.trim().equals("Error")) {
//                String[] r = result.split("-");
//
//
//            } else
//                Toast.makeText(getApplication(), "", Toast.LENGTH_LONG).show();
//            return sb.toString();
//        }
//
//        private void showToast(final String res) {
//            runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//                    //stuff that updates ui
//                    if (res.equals("1")) {
//                        Toast.makeText(getApplicationContext(), " Successfull", Toast.LENGTH_SHORT).show();
//
//                    } else {
//                        Toast.makeText(getApplicationContext(), " Failed ", Toast.LENGTH_SHORT).show();
//                    }
//                }
//            });
//        }
//    }
}
