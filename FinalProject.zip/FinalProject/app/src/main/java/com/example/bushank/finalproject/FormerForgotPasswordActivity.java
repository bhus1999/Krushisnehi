package com.example.bushank.finalproject;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 * Created by Sachin on 2/12/2020.
 */
public class FormerForgotPasswordActivity extends AppCompatActivity {

    TextInputLayout etMobile;
    Button btnSearch;
    String  strMobile;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formerforgotpassword);

        etMobile = (TextInputLayout) findViewById(R.id.et_formerforgotpass_mobile);
        btnSearch = (Button) findViewById(R.id.btn_formerforgotpass_search);

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                strMobile = etMobile.getEditText().getText().toString();
                if (strMobile.length() > 0)
                {
                    //new MyAsyncTask().execute();
                    StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().detectActivityLeaks().detectLeakedClosableObjects().penaltyLog().build());
                }
                else
                {
                    Toast.makeText(FormerForgotPasswordActivity.this, "Enter Registered Mobile Number", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

//
//
//    private class MyAsyncTask extends AsyncTask<String,Void,String> {
//        private ProgressDialog progressDialog = new ProgressDialog(FormerForgotPasswordActivity.this);
//        @Override
//        protected void onPreExecute() {
//            progressDialog.setMessage("Checking your mobile no for password.");
//            progressDialog.setTitle("ForgotPassword?");
//            progressDialog.show();
//            progressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
//                @Override
//                public void onCancel(DialogInterface dialogInterface) {
//                    MyAsyncTask.this.cancel(true);
//                }
//            });
//            super.onPreExecute();
//        }
//
//        @Override
//        protected String doInBackground(String... strings) {
//            postData(strMobile);
//            progressDialog.dismiss();
//            return null;
//        }
//
//
//        public void postData(String strMobile)
//        {
//            HttpClient httpClient = new DefaultHttpClient();
//            HttpPost httpPost = new HttpPost("https://phraseological-acco.000webhostapp.com/api/krushi_former_forgot_password.php");
//            try
//            {
//                ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
//                nameValuePairs.add(new BasicNameValuePair("f1",strMobile));
//                httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
//                Log.d("nameValuePairs",""+nameValuePairs);
//                HttpResponse response = httpClient.execute(httpPost);
//                HttpEntity entity = response.getEntity();
//                if (entity != null)
//                {
//                    InputStream stream = entity.getContent();
//                    String result=convertStreamToString(stream);
//                    Log.d("Result",result);
//
//                    JSONArray array=new JSONArray(result);
//                    for (int i=0;i<array.length();i++)
//                    {
//                        JSONObject object = array.getJSONObject(i);
//                        final String name = object.getString("password");
//                        if(name.equals("NO"))
//                        {runOnUiThread(new Runnable() {
//                            @Override
//                            public void run() {
//                                Toast.makeText(FormerForgotPasswordActivity.this, "Entered mobile no is not registered or wrong.", Toast.LENGTH_LONG).show();
//                            }
//                        });}
//                        else {
//                            runOnUiThread(new Runnable() {
//                                @Override
//                                public void run() {
//                                    Toast.makeText(FormerForgotPasswordActivity.this, "Hi Your passowrd is :" + name , Toast.LENGTH_SHORT).show();
//                                }
//                            });
//
//                        }
//                    }
//                }
//                else
//                {
//                    Toast.makeText(FormerForgotPasswordActivity.this, "Mobile number not found in records.", Toast.LENGTH_SHORT).show();
//                }
//            }
//            catch (final Exception ex)
//            {
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        Toast.makeText(FormerForgotPasswordActivity.this, "Error"+ex.getMessage(), Toast.LENGTH_SHORT).show();
//                    }
//                });
//            }
//        }
//
//        private String convertStreamToString(InputStream is) {
//
//            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
//            StringBuilder sb = new StringBuilder();
//
//            String line = null;
//            try {
//                while ((line = reader.readLine()) != null) {
//                    sb.append(line + "\n");
//                }
//            } catch (Exception ex) {
//                Toast.makeText(getApplication(), ex.getMessage(), Toast.LENGTH_LONG).show();
//            }
//
//            result = sb.toString().trim();
//
//
//            result = result.substring(1, result.length() - 1);
//
//            if (!result.trim().equals("Error")) {
//                String[] r = result.split("-");
//
//
//            } else
//                Toast.makeText(getApplication(), "", Toast.LENGTH_LONG).show();
//            return sb.toString();
//
//        }
//
//        private void showToast(final String res) {
//            runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//                    //stuff that updates ui
//                    if (res.equals("1")) {
//                        Toast.makeText(getApplicationContext(), " Successfull", Toast.LENGTH_SHORT).show();
//
//                    } else {
//                        Toast.makeText(getApplicationContext(), " Failed ", Toast.LENGTH_SHORT).show();
//                    }
//                }
//            });
//        }
//    }

}
