package com.example.bushank.finalproject;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by Sachin on 2/12/2020.
 */
public class FormerUpdateProduct1Activity extends AppCompatActivity{

    EditText etPid, etPname, etCategory, etCity, etPrice, etMobile, etQuantity, etDescription;
    String strMobile, strPid, strPname, strCategory, strCity, strPrice, strQuantity, strDescription;
    Button btnUpdate;
    SharedPrefHandler sharedPrefHandler;
    List<Product> productList;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formerupdateproduct1);
        sharedPrefHandler = new SharedPrefHandler(this);
        strMobile = sharedPrefHandler.getSharedPreferences("former_mobile");
        strPid = sharedPrefHandler.getSharedPreferences("product_id");

        etPid = (EditText) findViewById(R.id.et_formerupdateproduct1_pid);
        etPname = (EditText) findViewById(R.id.et_formerupdateproduct1_pname);
        etCategory = (EditText) findViewById(R.id.et_formerupdateproduct1_category);
        etCity = (EditText) findViewById(R.id.et_formerupdateproduct1_city);
        etPrice = (EditText) findViewById(R.id.et_formerupdateproduct1_price);
        etMobile = (EditText) findViewById(R.id.et_formerupdateproduct1_mobile);
        etQuantity = (EditText) findViewById(R.id.et_formerupdateproduct1_quantity);
        etDescription = (EditText) findViewById(R.id.et_formerupdateproduct1_description);
        btnUpdate = (Button) findViewById(R.id.btn_formerupdateproduct1_update);



        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                strPname = etPname.getText().toString();
                strCategory = etCategory.getText().toString();
                strCity = etCity.getText().toString();
                strPrice = etPrice.getText().toString();
                strQuantity = etQuantity.getText().toString();
                strDescription = etDescription.getText().toString();

                UpdateProfile();
            }
        });

        getProductByCode(strMobile,strPid);


        etMobile.setText(strMobile);
        etPid.setText(strPid);
    }



    private void getProductByCode(final String strMobile,final  String strPid) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();

        Api api = retrofit.create(Api.class);

        Call<List<Product>> call = api.getProductId(strMobile,strPid);

        call.enqueue(new Callback<List<Product>>() {
            @Override
            public void onResponse(Call<List<Product>> call, Response<List<Product>> response) {
                productList = response.body();

                Boolean isSuccess = false;
                if (response.body() != null) {
                    isSuccess = true;
                }

                if (isSuccess) {
                    etPname.setText(productList.get(0).getproduct_name());
                    etCategory.setText(productList.get(0).getcategory());
                    etCity.setText(productList.get(0).getcity());
                    etPrice.setText(productList.get(0).getprice());
                    etQuantity.setText(productList.get(0).getquantity());
                    etDescription.setText(productList.get(0).getdescription());


                    //finish();

                } else {

                }
            }

            @Override
            public void onFailure(Call<List<Product>> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void UpdateProfile() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        Api api = retrofit.create(Api.class);

        Call<IsExist> call = api.UpdateProduct(
                strMobile, strPid, strPname, strCategory, strCity, strPrice, strQuantity, strDescription
        );

        call.enqueue(new Callback<IsExist>() {
            @Override
            public void onResponse(Call<IsExist> call, Response<IsExist> response) {
                IsExist responseResult = response.body();

                Boolean isSuccess = false;
                if (responseResult != null) {
                    isSuccess = responseResult.getSuccess();
                }

                if (isSuccess) {


                } else {
                    // Show Creation Failed Message

                }
            }

            @Override
            public void onFailure(Call<IsExist> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }







//    private class MyAsyncTask extends AsyncTask<String, Void, String>
//    {
//        private ProgressDialog progressDialog = new ProgressDialog(FormerUpdateProduct1Activity.this);
//
//        protected void onPreExecute()
//        {
//            progressDialog.setMessage("Please Wait");
//            progressDialog.show();
//
//        }
//        public void postData(String strPid, String strPname, String strCategory, String strCity, String strPrice,
//                             String strMobile, String strQuantity, String strDescription)
//        {
//            // Create a new HttpClient and Post Header
//            HttpClient httpclient = new DefaultHttpClient();
//            HttpPost httppost = new HttpPost("https://phraseological-acco.000webhostapp.com/api/krushi_update_product.php");
//
//            try {
//                ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
//                //nameValuePairs.add(new BasicNameValuePair("f1", usn));
//                nameValuePairs.add(new BasicNameValuePair("f1", strPid));
//                nameValuePairs.add(new BasicNameValuePair("f2", strPname));
//                nameValuePairs.add(new BasicNameValuePair("f3", strCategory));
//                nameValuePairs.add(new BasicNameValuePair("f4", strCity));
//                nameValuePairs.add(new BasicNameValuePair("f5", strPrice));
//                nameValuePairs.add(new BasicNameValuePair("f6", strMobile));
//                nameValuePairs.add(new BasicNameValuePair("f7", strQuantity));
//                nameValuePairs.add(new BasicNameValuePair("f8", strDescription));
//
//                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
//                Log.d("nameValuePairs", "" + nameValuePairs);
//                HttpResponse response = httpclient.execute(httppost);
//
//                HttpEntity entity = response.getEntity();
//
//
//                // If the response does not enclose an entity, there is no need
//                if (entity != null) {
//                    InputStream instream = entity.getContent();
//
//                    String result;
//                    result = convertStreamToString(instream);
//                    Log.d("respo", "" + result);
//                    JSONObject jsonObject = new JSONObject(result);
//                    String status = jsonObject.getString("success");
//                    Log.d("status", "" + status);
//
//
//                    if (status.equals("1"))
//
//                    {
//                        Intent intent=new Intent(getApplication(),FormerProductActivity.class);
//                        startActivity(intent);
//                    }
//                    else
//                    {
//
//                    }
//
//
//                }
//
//
//            } catch (Exception e)
//            {
//                e.printStackTrace();
//            }
//        }
//
//        @Override
//        protected String doInBackground (String...params)
//        {
//            postData(strPid, strPname, strCategory, strCity, strPrice, strMobile, strQuantity, strDescription);
//            progressDialog.dismiss();
//            return null;
//        }
//        private  String convertStreamToString(InputStream is)
//        {
//            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
//            StringBuilder sb = new StringBuilder();
//
//            String line = null;
//            try {
//                while ((line = reader.readLine()) != null)
//                {
//                    sb.append(line + "\n");
//                }
//            }
//            catch (IOException e)
//            {
//                e.printStackTrace();
//            }
//            finally
//            {
//                try
//                {
//                    is.close();
//                } catch (IOException e)
//                {
//                    e.printStackTrace();
//                }
//            }
//            return sb.toString();
//        }
//    }
//    private void showToast(final String res)
//    {
//        runOnUiThread(new Runnable()
//        {
//            @Override
//            public void run()
//            {
//                //stuff that updates ui
//                if (res.equals("1"))
//                {
//                    Toast.makeText(getApplicationContext(), "  Account Create  Successful ", Toast.LENGTH_SHORT).show();
//
//                }
//                else
//                {
//                    Toast.makeText(getApplicationContext(), "Account Create Failed ", Toast.LENGTH_SHORT).show();
//                }
//            }
//        });
//    }
//
//
//
//    private class MyAsyncTask1 extends AsyncTask<String, Void, String> {
//        private ProgressDialog progressDialog = new ProgressDialog(FormerUpdateProduct1Activity.this);
//
//        protected void onPreExecute() {
//            progressDialog.setMessage("Fetching data...");
//            progressDialog.show();
//            progressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
//                @Override
//                public void onCancel(DialogInterface arg0) {
//                    MyAsyncTask1.this.cancel(true);
//                }
//            });
//        }
//
//        public void postData(String strPid, String strMobile) {
//
//
//            // Create a new HttpClient and Post Header
//            HttpClient httpclient = new DefaultHttpClient();
//            HttpPost httppost = new HttpPost("https://phraseological-acco.000webhostapp.com/api/krushi_fetch_product_details.php");
//
//            try {
//                ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
//                nameValuePairs.add(new BasicNameValuePair("f1", strPid));
//                nameValuePairs.add(new BasicNameValuePair("f2", strMobile));
//
//                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
//                Log.d("nameValuePairs", "" + nameValuePairs);
//                HttpResponse response = httpclient.execute(httppost);
//                HttpEntity entity = response.getEntity();
//
//
//                // If the response does not enclose an entity, there is no need
//                if (entity != null) {
//                    InputStream instream = entity.getContent();
//
//                    String result;
//                    result = convertStreamToString(instream);
//                    Log.d("aaa","" + result);
//
//
//                    JSONArray arr = new JSONArray(result);
//                    for (int i = 0; i < arr.length(); i++) {
//                        JSONObject jsonObject = arr.getJSONObject(i);
//                        String product_name = jsonObject.getString("product_name");
//                        String category = jsonObject.getString("category");
//                        String city = jsonObject.getString("city");
//                        String price = jsonObject.getString("price");
//                        String quantity = jsonObject.getString("quantity");
//                        String description = jsonObject.getString("description");
//
//                        //jsonObject.getString("name");
//
//                        setdata(product_name, category, city, price, quantity, description);
//                    }
//                }
//
//            } catch (Exception e) {
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        Toast.makeText(getApplicationContext(), "Something went wrong.Please try again.", Toast.LENGTH_LONG).show();
//                    }
//                });
//            }
//        }
//
//        public void setdata( final  String product_name, final  String  category, final  String  city, final  String  price,
//                             final  String quantity,final  String description)
//        {
//            runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//                    etPname.setText(product_name);
//                    etCategory.setText(category);
//                    etCity.setText(city);
//                    etPrice.setText(price);
//                    etQuantity.setText(quantity);
//                    etDescription.setText(description);
//                }
//            });
//        }   //etPname,etCategory,etCity,etPrice,etQuantity,etDescription
//
//        @Override
//        protected String doInBackground(String... params) {
//            postData(strPid, strMobile);
//            //start loading proggress dialog
//            //pd= ProgressDialog.show(Chg_Password.this, "Loading...","");
//            this.progressDialog.dismiss();
//            return null;
//
//        }
//
//        /*
//        @Override
//
//        protected void onPostExecute(String s) {
//            super.onPostExecute(s);
//            //dissmiss
//            //pd.dismiss();
//            adp.notifyDataSetChanged();
//        }
//        */
//
//        private String convertStreamToString(InputStream is) {
//
//            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
//            StringBuilder sb = new StringBuilder();
//
//            String line = null;
//            try {
//                while ((line = reader.readLine()) != null) {
//                    sb.append(line + "\n");
//                }
//            } catch (Exception ex) {
//                Toast.makeText(getApplication(), ex.getMessage(), Toast.LENGTH_LONG).show();
//            }
//
//            result = sb.toString().trim();
//
//
//            result = result.substring(1, result.length() - 1);
//
//            if (!result.trim().equals("Error")) {
//                String[] r = result.split("-");
//
//            } else
//                Toast.makeText(getApplication(), "", Toast.LENGTH_LONG).show();
//            return sb.toString();
//        }
//
//        private void showToast(final String res) {
//            runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//                    //stuff that updates ui
//                    if (res.equals("1")) {
//                        Toast.makeText(getApplicationContext(), " Successfull", Toast.LENGTH_SHORT).show();
//
//                    } else {
//                        Toast.makeText(getApplicationContext(), " Failed ", Toast.LENGTH_SHORT).show();
//                    }
//                }
//            });
//        }
//
//    }
}
