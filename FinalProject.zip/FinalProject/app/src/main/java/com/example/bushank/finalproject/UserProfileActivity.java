package com.example.bushank.finalproject;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by Sachin on 2/12/2020.
 */
public class UserProfileActivity extends AppCompatActivity{

    EditText etUserName, etMobile, etEmail, etCity, etAddress, etPassword;
    Button btnUpdate;
    String strMobile, strName, strEmail, strCity, strAddress, strPassword;
    SharedPrefHandler sharedPrefHandler;
    List<User> productList;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userprofile);
        sharedPrefHandler = new SharedPrefHandler(this);
        strMobile = sharedPrefHandler.getSharedPreferences("user_mobile");


        etUserName = (EditText) findViewById(R.id.et_user_profile_username);
        etMobile = (EditText) findViewById(R.id.et_user_profile_mobile);
        etEmail = (EditText) findViewById(R.id.et_user_profile_email);
        etCity = (EditText) findViewById(R.id.et_user_profile_city);
        etAddress = (EditText) findViewById(R.id.et_user_profile_address);
        etPassword = (EditText) findViewById(R.id.et_user_profile_password);
        btnUpdate = (Button) findViewById(R.id.btn_userprofile_update);

        etMobile.setText(strMobile);

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                strName = etUserName.getText().toString();
                strEmail = etEmail.getText().toString();
                strCity = etCity.getText().toString();
                strAddress = etAddress.getText().toString();
                strPassword = etPassword.getText().toString();

                UpdateProfile();
                Intent intent=new Intent(getApplication(),UserHomeActivity.class);
                startActivity(intent);
                finish();

            }
        });

        getProductByCode(strMobile);
    }


    private void getProductByCode(final String strMobile) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();

        Api api = retrofit.create(Api.class);

        Call<List<User>> call = api.getUserAccount(strMobile);

        call.enqueue(new Callback<List<User>>() {
            @Override
            public void onResponse(Call<List<User>> call, Response<List<User>> response) {
                productList = response.body();

                Boolean isSuccess = false;
                if (response.body() != null) {
                    isSuccess = true;
                }

                if (isSuccess) {
                    etUserName.setText(productList.get(0).getuser_name());
                    etCity.setText(productList.get(0).getcity());
                    etAddress.setText(productList.get(0).getaddress());
                    etPassword.setText(productList.get(0).getpassword());
                    etEmail.setText(productList.get(0).getemail());



                    //finish();

                } else {

                }
            }

            @Override
            public void onFailure(Call<List<User>> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void UpdateProfile() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        Api api = retrofit.create(Api.class);

        Call<IsExist> call = api.UpdateUserAccount(
                strMobile, strName, strEmail, strCity, strAddress, strPassword



        );

        call.enqueue(new Callback<IsExist>() {
            @Override
            public void onResponse(Call<IsExist> call, Response<IsExist> response) {
                IsExist responseResult = response.body();

                Boolean isSuccess = false;
                if (responseResult != null) {
                    isSuccess = responseResult.getSuccess();
                }

                if (isSuccess) {


                } else {
                    // Show Creation Failed Message

                }
            }

            @Override
            public void onFailure(Call<IsExist> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }








//    private class MyAsyncTask extends AsyncTask<String, Void, String>
//    {
//        private ProgressDialog progressDialog = new ProgressDialog(UserProfileActivity.this);
//
//        protected void onPreExecute()
//        {
//            progressDialog.setMessage("Please Wait");
//            progressDialog.show();
//
//        }
//        public void postData(String strName, String strMobile, String strEmail, String strCity, String strAddress,
//                             String strPassword)
//        {
//            // Create a new HttpClient and Post Header
//            HttpClient httpclient = new DefaultHttpClient();
//            HttpPost httppost = new HttpPost("https://phraseological-acco.000webhostapp.com/api/krushi_update_user_profile.php");
//
//            try {
//                ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
//                //nameValuePairs.add(new BasicNameValuePair("f1", usn));
//                nameValuePairs.add(new BasicNameValuePair("f1", strName));
//                nameValuePairs.add(new BasicNameValuePair("f2", strMobile));
//                nameValuePairs.add(new BasicNameValuePair("f3", strEmail));
//                nameValuePairs.add(new BasicNameValuePair("f4", strCity));
//                nameValuePairs.add(new BasicNameValuePair("f5", strAddress));
//                nameValuePairs.add(new BasicNameValuePair("f6", strPassword));
//
//                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
//                Log.d("nameValuePairs", "" + nameValuePairs);
//                HttpResponse response = httpclient.execute(httppost);
//
//                HttpEntity entity = response.getEntity();
//
//
//                // If the response does not enclose an entity, there is no need
//                if (entity != null) {
//                    InputStream instream = entity.getContent();
//
//                    String result;
//                    result = convertStreamToString(instream);
//                    Log.d("respo", "" + result);
//                    JSONObject jsonObject = new JSONObject(result);
//                    String status = jsonObject.getString("success");
//                    Log.d("status", "" + status);
//
//
//                    if (status.equals("1"))
//
//                    {
//                        Intent intent=new Intent(getApplication(),UserHomeActivity.class);
//                        startActivity(intent);
//                    }
//                    else
//                    {
//
//                    }
//
//
//                }
//
//
//            } catch (Exception e)
//            {
//                e.printStackTrace();
//            }
//        }
//
//        @Override
//        protected String doInBackground (String...params)
//        {
//            postData(strName, strMobile, strEmail, strCity, strAddress, strPassword);
//            progressDialog.dismiss();
//            return null;
//        }
//        private  String convertStreamToString(InputStream is)
//        {
//            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
//            StringBuilder sb = new StringBuilder();
//
//            String line = null;
//            try {
//                while ((line = reader.readLine()) != null)
//                {
//                    sb.append(line + "\n");
//                }
//            }
//            catch (IOException e)
//            {
//                e.printStackTrace();
//            }
//            finally
//            {
//                try
//                {
//                    is.close();
//                } catch (IOException e)
//                {
//                    e.printStackTrace();
//                }
//            }
//            return sb.toString();
//        }
//    }
//    private void showToast(final String res)
//    {
//        runOnUiThread(new Runnable()
//        {
//            @Override
//            public void run()
//            {
//                //stuff that updates ui
//                if (res.equals("1"))
//                {
//                    Toast.makeText(getApplicationContext(), "  Account Create  Successful ", Toast.LENGTH_SHORT).show();
//
//                }
//                else
//                {
//                    Toast.makeText(getApplicationContext(), "Account Create Failed ", Toast.LENGTH_SHORT).show();
//                }
//            }
//        });
//    }
//
//
//
//    private class MyAsyncTask1 extends AsyncTask<String, Void, String> {
//        private ProgressDialog progressDialog = new ProgressDialog(UserProfileActivity.this);
//
//        protected void onPreExecute() {
//            progressDialog.setMessage("Fetching data...");
//            progressDialog.show();
//            progressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
//                @Override
//                public void onCancel(DialogInterface arg0) {
//                    MyAsyncTask1.this.cancel(true);
//                }
//            });
//        }
//
//        public void postData(String strMobile) {
//
//
//            // Create a new HttpClient and Post Header
//            HttpClient httpclient = new DefaultHttpClient();
//            HttpPost httppost = new HttpPost("https://phraseological-acco.000webhostapp.com/api/krushi_fetch_user_profile.php");
//
//            try {
//                ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
//                nameValuePairs.add(new BasicNameValuePair("f1", strMobile));
//
//                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
//                Log.d("nameValuePairs", "" + nameValuePairs);
//                HttpResponse response = httpclient.execute(httppost);
//                HttpEntity entity = response.getEntity();
//
//
//                // If the response does not enclose an entity, there is no need
//                if (entity != null) {
//                    InputStream instream = entity.getContent();
//
//                    String result;
//                    result = convertStreamToString(instream);
//                    Log.d("aaa","" + result);
//
//
//                    JSONArray arr = new JSONArray(result);
//                    for (int i = 0; i < arr.length(); i++) {
//                        JSONObject jsonObject = arr.getJSONObject(i);
//                        String user_name = jsonObject.getString("user_name");
//                        String email = jsonObject.getString("email");
//                        String city = jsonObject.getString("city");
//                        String address = jsonObject.getString("address");
//                        String password = jsonObject.getString("password");
//
//                        //jsonObject.getString("name");
//
//                        setdata(user_name, email, city, address, password);
//                    }
//                }
//
//            } catch (Exception e) {
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        Toast.makeText(getApplicationContext(), "Something went wrong.Please try again.", Toast.LENGTH_LONG).show();
//                    }
//                });
//            }
//        }
//
//        public void setdata( final  String user_name, final  String  email, final  String  city, final  String  address,
//                             final  String password)
//        {
//            runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//                    etUserName.setText(user_name);
//                    etEmail.setText(email);
//                    etCity.setText(city);
//                    etAddress.setText(address);
//                    etPassword.setText(password);
//                }
//            });
//        }
//
//        @Override
//        protected String doInBackground(String... params) {
//            postData(strMobile);
//            //start loading proggress dialog
//            //pd= ProgressDialog.show(Chg_Password.this, "Loading...","");
//            this.progressDialog.dismiss();
//            return null;
//
//        }
//
//        /*
//        @Override
//
//        protected void onPostExecute(String s) {
//            super.onPostExecute(s);
//            //dissmiss
//            //pd.dismiss();
//            adp.notifyDataSetChanged();
//        }
//        */
//
//        private String convertStreamToString(InputStream is) {
//
//            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
//            StringBuilder sb = new StringBuilder();
//
//            String line = null;
//            try {
//                while ((line = reader.readLine()) != null) {
//                    sb.append(line + "\n");
//                }
//            } catch (Exception ex) {
//                Toast.makeText(getApplication(), ex.getMessage(), Toast.LENGTH_LONG).show();
//            }
//
//            result = sb.toString().trim();
//
//
//            result = result.substring(1, result.length() - 1);
//
//            if (!result.trim().equals("Error")) {
//                String[] r = result.split("-");
//
//            } else
//                Toast.makeText(getApplication(), "", Toast.LENGTH_LONG).show();
//            return sb.toString();
//        }
//
//        private void showToast(final String res) {
//            runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//                    //stuff that updates ui
//                    if (res.equals("1")) {
//                        Toast.makeText(getApplicationContext(), " Successfull", Toast.LENGTH_SHORT).show();
//
//                    } else {
//                        Toast.makeText(getApplicationContext(), " Failed ", Toast.LENGTH_SHORT).show();
//                    }
//                }
//            });
//        }
//
//    }


}
