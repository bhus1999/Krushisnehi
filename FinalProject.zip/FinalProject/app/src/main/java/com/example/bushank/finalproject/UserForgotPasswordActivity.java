package com.example.bushank.finalproject;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 * Created by Sachin on 2/12/2020.
 */
public class UserForgotPasswordActivity extends AppCompatActivity {

    TextInputLayout etMobile;
    Button btnSearch;
    String  strMobile;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userforgot);

        etMobile = (TextInputLayout) findViewById(R.id.et_userforgotpass_mobile);
        btnSearch = (Button) findViewById(R.id.btn_userforgotpass_search);

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                strMobile = etMobile.getEditText().getText().toString();
                if (strMobile.length() > 0)
                {

                    StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().detectActivityLeaks().detectLeakedClosableObjects().penaltyLog().build());
                }
                else
                {
                    Toast.makeText(UserForgotPasswordActivity.this, "Enter Registered Mobile Number", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }




}
