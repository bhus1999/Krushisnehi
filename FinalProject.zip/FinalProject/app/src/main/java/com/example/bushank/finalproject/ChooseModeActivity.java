package com.example.bushank.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.view.View;

public class ChooseModeActivity extends AppCompatActivity
{

    CardView cvFormer, cvUser;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choosemode);

        cvFormer= (CardView) findViewById(R.id.cv_choosemode_former);
        cvUser= (CardView) findViewById(R.id.cv_choosemode_user);

        cvFormer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplication(), FormerLoginActivity.class);
                startActivity(i);
            }
        });

        cvUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplication(), UserLoginActivity.class);
                startActivity(i);
            }
        });
    }
}
